package com.spring.apialunos.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.spring.apialunos.entity.Aluno;


public interface AlunoRepository extends CrudRepository<Aluno, Long>{

	@Query("SELECT p FROM ApiAlunos p WHERE p.nome LIKE :nome%")
	Iterable<Aluno> findByNome(String nome);
}
