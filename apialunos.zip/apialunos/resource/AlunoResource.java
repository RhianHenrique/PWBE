package com.spring.apialunos.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.apialunos.entity.Aluno;
import com.spring.apialunos.repository.AlunoRepository;

@RestController
@RequestMapping("/aluno")
public class AlunoResource {
	
	@Autowired
	private AlunoRepository alunoRepository;
	
	@GetMapping("senai/api/consulta_todos")
	public Iterable<Aluno> findAll(){
		return alunoRepository.findAll();
	}
	
	@GetMapping("senai/api/consulta/{id}")
	public Aluno findById(@PathVariable Long id) {
		return alunoRepository.findById(id).orElse(null);
	}
	
	@PostMapping("/senai/api/criar")
	public Aluno createAluno(@RequestBody Aluno aluno) {
		String url = "https://viacep.com.br/ws/" + aluno.getCep() + "/json/";
		return alunoRepository.save(aluno);
	}
	
	@PutMapping("/senai/api/atualiza/{id}")
	public Aluno updateAluno(@PathVariable Long id, @RequestBody Aluno aluno) {
		aluno.setId(id);
		return alunoRepository.save(aluno);
	}
	
	@DeleteMapping("/senai/api/delete/{id}")
	public void deleteAluno(@PathVariable Long id) {
		alunoRepository.deleteById(id);
	}
	
	//@GetMapping("/senai/api/relatorio")
	
	

}
