package com.spring.apialunos.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "file")
public class ArquivoConfig {
	
    // Variável para armazenar o diretório de upload configurado.
    private String uploadDir;

    // Método getter para obter o diretório de upload.
    public String getUploadDir() {
        return uploadDir;
    }

    // Método setter para configurar o diretório de upload.
    public void setUploadDir(String uploadDir) {
        this.uploadDir = uploadDir;
    }

}
