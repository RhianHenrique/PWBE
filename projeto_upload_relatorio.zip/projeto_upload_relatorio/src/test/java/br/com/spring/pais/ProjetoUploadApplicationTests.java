package br.com.spring.pais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
