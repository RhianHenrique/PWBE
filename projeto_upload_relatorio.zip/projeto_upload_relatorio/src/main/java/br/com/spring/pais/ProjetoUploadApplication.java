package br.com.spring.pais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoUploadApplication.class, args);
	}

}
