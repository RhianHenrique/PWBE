package com.example.projetobanco.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.projetobanco.model.Carro;

public interface CarroRepository extends CrudRepository<Carro, Integer>{
	@Query("SELECT c FROM carro c WHERE c.nome LIKE %:nome%")
	Iterable<Carro> findByName(String nome);

}
