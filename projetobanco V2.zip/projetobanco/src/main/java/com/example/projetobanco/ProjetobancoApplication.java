package com.example.projetobanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetobancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetobancoApplication.class, args);
	}

}
