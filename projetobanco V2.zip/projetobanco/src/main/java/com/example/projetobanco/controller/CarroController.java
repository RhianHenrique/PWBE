package com.example.projetobanco.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.projetobanco.model.Carro;
import com.example.projetobanco.repository.CarroRepository;

@RestController
@RequestMapping("/carros")
public class CarroController {
	
	@Autowired
	private CarroRepository carroRepository;
	
	@GetMapping
	public Iterable<Carro> getCarros(){
		return carroRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public Carro buscarCarroPorId(@PathVariable Integer id) {
		return carroRepository.findById(id).orElse(null);
	}
	
	//Para adicionar um carro
	@PostMapping
	public Carro adicionarCarro(@RequestBody Carro carro) {
		return carroRepository.save(carro);
	}
	
	//Para atualizar um objeto carro
	@PutMapping("/{id}")
	public Carro atualizarCarro(@PathVariable Integer id, @RequestBody Carro carro) {
		return carroRepository.save(carro);
	}
	
	@DeleteMapping("/{id}")
	public void deletarCarro(@PathVariable Integer id) {
		carroRepository.deleteById(id);
	}

}
