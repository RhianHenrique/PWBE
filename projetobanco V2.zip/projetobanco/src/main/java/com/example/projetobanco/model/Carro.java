package com.example.projetobanco.model;

import java.io.Serializable;
import java.util.Objects;

import org.springframework.data.annotation.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;


@Entity
public class Carro implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String nome;
	private String marca;
	private int ano;
	private String cor;
	
	public Carro() {
		
	}
	
	public Carro(String nome, String marca, int ano, String cor) {
		super();
		this.nome = nome;
		this.marca = marca;
		this.ano = ano;
		this.cor = cor;
	}

	public Integer getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getMarca() {
		return marca;
	}

	public int getAno() {
		return ano;
	}

	public String getCor() {
		return cor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(ano, cor, marca, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Carro other = (Carro) obj;
		return ano == other.ano && Objects.equals(cor, other.cor) && Objects.equals(marca, other.marca)
				&& Objects.equals(nome, other.nome);
	}

	@Override
	public String toString() {
		return "Carro [id=" + id + ", nome=" + nome + ", marca=" + marca + ", ano=" + ano + ", cor=" + cor + "]";
	}
	
	
	
	
}
	
